const MongoClient = require('mongodb').MongoClient;

const url = 'mongodb://localhost:27017';

let connection;
let db;

function connect() {
    return MongoClient.connect(url)
        .then(function (connect) {
            connection = connect;
            console.log('Соедирение установлено');
            db = connect.db('Yasli');
            return db;
        })
        .catch(err => console.error(err));
}

module.exports = function () {
    return connection && connection.isConnected() 
    ? Promise.resolve(db) 
    : connect();
}