const express = require('express');
const bodyParser = require('body-parser');
const getDb = require('./db');

const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

const port = 8000

app.listen(port, function () {
    console.log(`Сервер запущен http://localhost:${port}`);
});

app.get('/', function (req, res) {
    getDb()
        .then(db => {
            const collection = db.collection('Temp');
            return collection.find({}).toArray()
        })
        .then(docs => res.send(JSON.stringify(docs)))
        .catch(err => console.error(err))
});

app.get('/create', function (req, res) {
    const html = require('./templates/create')();
    res.send(html);
});
app.post('/create', function (req, res) {
    getDb()
        .then(db => {
            console.log(req.body);
            const collection = db.collection('Temp');
            return collection.insertOne(req.body)
        })
        .then(docs => res.redirect('/'))
        .catch(err => console.error(err))
});