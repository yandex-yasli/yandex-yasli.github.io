const MongoClient = require('mongodb').MongoClient;
const ObjectId = require('mongodb').ObjectId;

const url = 'mongodb://localhost:27017';

MongoClient.connect(url)
    .then(function (connect) {
        console.log('Соедирение установлено');
        const db = connect.db('Yasli');
        remove(db);
    })
    .catch(err => console.error(err));

function create(db) {
    const docs = [
        {
            name: "Работает 1!"
        },
        {
            name: "Работает 2!"
        }
    ];

    const collection = db.collection('Temp');
    collection.insertOne(null)
        .then(res => console.log(res.result))
        .catch(err => console.error(err))
}


function read(db) {
    const collection = db.collection('Temp');
    collection.find({ _id: ObjectId('5cd1a3db822e9a85ebedafae') }, { fields: { 'name': 1, '_id': 0 } }).toArray()
        .then(docs => console.log(docs))
        .catch(err => console.error(err))
}

function update(db) {
    const docId = ObjectId('5cd1a3db822e9a85ebedafae');

    const collection = db.collection('Temp');
    collection.updateMany({ name: { gt: 56}  }, { $set: { 'name': 'Ура, работает!' } })
        .then(res => console.log(res.result))
        .catch(err => console.error(err));
}

function remove(db) {
    const docId = ObjectId('5cd1a3db822e9a85ebedafae');

    const collection = db.collection('Temp');
    collection.deleteOne({ _id: docId  })
        .then(res => console.log(res.result))
        .catch(err => console.error(err));
}
