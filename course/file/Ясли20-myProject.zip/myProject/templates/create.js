module.exports = function() {
    return `
        <form method="POST">
            <input type="text" placeholder="Название" name="name" />
            <br/>
            <textarea placeholder="Текст" name="text"></textarea>
            <br/>
            <button type="submit">Сохранить</button>
        </form>
    `;
}