const db = require('./db.json');
const photoTemplate = require('../templates/photo.template');
const dustyEngine = require('dusty-template-engine');

module.exports = function(app) {
    app.get('/', (req, res) => {
        res.send('<h1>Hello World!</h1><img src="/images/fallback.png"><a href="/contacts">Контакты</a>');
    });

    app.get('/contacts', (req, res) => res.send(`<h1>Это страница контактов</h1>
    <form method="POST" action="/message" enctype="application/x-www-form-urlencoded">
    <h2>Напишите нам</h2><textarea name="message"></textarea>
    <button>Отправить</button>
    </form>`));

    app.get('/users/:userId', function (req, res) {
        res.send(req.params);
    });

    app.post('/message', (req, res) => {
        console.log(req.body);

        res.send('<h1>Hello World!</h1><a href="/contacts">Контакты</a>');
    });

    app.get('/photo', (req, res) => {
        const photoId = req.query.photo;

        if (!photoId) {
            res.sendStatus(401);

            return;
        }


        const element = db.find(element => {
            return element.id === photoId;
        });

        if (!element) {
            res.sendStatus(404);

            return;
        }

        res.send(dustyEngine(photoTemplate(element)));
    });
}
