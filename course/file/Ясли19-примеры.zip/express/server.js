const express = require('express');
const app = express();
const port = 3000;

const routes = require('./app/routes');


app.use('/message', express.urlencoded());
app.use(express.static('public'));

var myLogger = function (req, res, next) {
    console.log('LOGGED');
    next();
}

app.use(myLogger);

routes(app);

app.listen(port,
  () => console.log(`Example app listening on port ${port}!`)
);
