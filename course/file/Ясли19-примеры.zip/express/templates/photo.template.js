module.exports = function photoJSTemplate(photo) {
    return {
        tag: 'article',
        cls: 'photo',
        attrs: { style: `background-image: url(${photo.urls.small})` },
        content: {
            tag: 'footer',
            content: [
                {
                    tag: 'span',
                    cls: 'avatar',
                    content: {
                        tag: 'img',
                        attrs: { src: photo.user.profile_image.medium }
                    }
                },
                { tag: 'h2', content: photo.user.name },
                photo.user.instagram_username && {
                    tag: 'a',
                    cls: 'social',
                    href: `https://www.instagram.com/${photo.user.instagram_username}`,
                    content: { tag: 'i', cls: ['fab', 'fa-instagram'] }
                },
                {
                    tag: 'span',
                    cls: 'rating',
                    content: [
                        {
                            tag: 'i',
                            cls: ['fa', 'fa-heart']
                        },
                        ' ',
                        photo.likes
                    ]
                }
            ]
        }
    }
};
