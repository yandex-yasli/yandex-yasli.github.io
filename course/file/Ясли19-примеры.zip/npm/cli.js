#!/usr/bin/env node

const [,, ...args] = process.argv;

const engine = require('./template');

args.forEach(tmpl => {
    const template = require(tmpl);

    console.log(engine(template));
});
