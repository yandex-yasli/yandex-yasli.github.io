const selfClosingTags = [
    'area',
    'base',
    'br',
    'col',
    'embed',
    'hr',
    'img',
    'input',
    'keygen',
    'link',
    'menuitem',
    'meta',
    'param',
    'source',
    'track',
    'wbr'
];

function dustyTemplateEngine(block) {
    if ((block === undefined) || (block === null) || (block === false)) {
        return '';
    }
    if ((typeof block === 'string') || (typeof block === 'number') || (block === true)) {
        return block.toString();
    }
    if (Array.isArray(block)) {
        let fragment = '';
        block.forEach(el => {
            fragment += dustyTemplateEngine(el);
        });
        return fragment;
    }
    let element = '<' + block.tag;

    const classes = (Array.isArray(block.cls) ? block.cls : [block.cls]).filter(Boolean);

    if (classes.length) {
        element += ' class="';
        classes.forEach((cls, i) => {
            if (i > 0) element += ' ';
            element += cls;
        });
        element += '"';
    }

    //element.classList.add(...[].concat(block.cls).filter(Boolean));
    if (block.attrs) {
        Object.keys(block.attrs).forEach(key => {
            element += ' ';
            element += `${key}="${block.attrs[key]}"`;
        });
    }

    element += '>';

    if (selfClosingTags.includes(block.tag)) {
        return element;
    }

    element += dustyTemplateEngine(block.content) + '</' + block.tag + '>';

    return element;
}

if (module && module.exports) {
    module.exports = dustyTemplateEngine;
}
