Спасибо, <?php print($_REQUEST['name']) ?>!
Мы ответим вам в ближайшее время на <?php print($_REQUEST['email']) ?>

Текст сообщения:
<?php print($_REQUEST['message']) ?>