<h2>
    (3) Мне нравится фронтенд!
</h2>
<p>
    <img src="https://avatars.mds.yandex.net/get-pdb/750997/a49cea26-0d26-4fe7-8283-b894ef56fd38/s1200?webp=false" width=600>
</p>
<p>
    Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna
    aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
    Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur
    sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
</p>