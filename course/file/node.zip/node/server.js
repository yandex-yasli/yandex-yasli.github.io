const http = require('http');
const fs = require('fs');
const url = require('url');
const template = fs.readFileSync('./template.html', 'utf8');

const { addAnimal } = require('db');
const { hiAnimals } = require('./zoo');

const server = http.createServer();

server.listen(3999, '127.0.0.1');


server.on('request', function(request, response) {
    console.log('request');
    const urlParsed = url.parse(request.url, true);

    switch (urlParsed.pathname) {
        case '/promise':
            const promise = new Promise(resolve => {
                setTimeout(() => {
                    resolve('error');
                }, 1000);
            });

            promise.then((result) => {
                console.log('promise resolved');
                response.end(result);
            }).catch((error) => {
                console.log('promise rejected');
                response.end(error);
            })


            break;
        case '/':
            hiAnimals('<br/>').then(result => {
                const content = template.replace('{{content}}', result);
                response.end(content);
            }).catch(error => {
                console.error(new Error('File reading error: ' + error.message));
                response.statusCode = 500;
                response.end('Internal server error');
            });
            break;
        case '/add':
            const query = urlParsed.query;
            const id = query.name.toLowerCase();
            addAnimal(id, query.name, query.age, query.weight).then(() => {
                response.setHeader('Content-Type', 'text/html');
                response.end('Your animal successfuly saved! <a href="/">Go back</a>');
            }).catch(error => {
                console.error(new Error('File writing error: ' + error.message));
                response.statusCode = 500;
                response.end('Internal server error');
            });
            break;
        default:
            response.statusCode = 404;
            response.end('Page not found :(');
    }
});
