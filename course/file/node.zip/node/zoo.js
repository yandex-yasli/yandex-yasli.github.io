const { Animal } = require('./animal');
const { getAnimals } = require('db');

function hiAnimals(separator) {
    return getAnimals().then(animalsList => {
        return animalsList.map((animal) => new Animal(animal));
    }).then(talkingAnimalsList => {
        return talkingAnimalsList.length > 0 ?
            talkingAnimalsList.map((animal) => animal.hi()).join(separator) :
            'There is no animals in the Zoo :(';
    });
}

if (module.parent) {
    module.exports = { hiAnimals };
} else {
    hiAnimals('\n').then(result => {
        console.log(result);
    });
}
