function Animal(animal) {
    this.name = animal.name;
    this.age = animal.age;
    this.weight = animal.weight;
}

Animal.prototype.hi = function() {
    return 'Hi! I am ' + this.name;
};

module.exports.Animal = Animal;
